Here you will find few games and demos you can try ZXDS with to get you
started. Just put them to /ZXDS/Data/ directory where ZXDS looks for
files first by default.

Be sure to check http://zxds.raxoft.cz for more info on where you can find
lot more games and demos.
