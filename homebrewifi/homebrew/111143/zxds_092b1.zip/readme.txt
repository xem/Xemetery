This is ZXDS - Sinclair ZX Spectrum emulator for Nintendo DS.

For quick install, simply copy the entire ZXDS directory (not just its content,
but the directory itself) to the root of you card, making sure that even the
empty subdirectories are copied, then run ZXDS.nds as you run any other application.

For more detailed documentation, usage instructions and updates,
please go to http://zxds.raxoft.cz .

Among other things, it explains how to apply DLDI patches and how to create
.ds.gba version if you need one, which are the two things you might need to
do yourself before installing ZXDS on your card.

Enjoy!

Patrik Rak
