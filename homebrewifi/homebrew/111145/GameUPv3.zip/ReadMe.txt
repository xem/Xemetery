+--[ GameUP - v3.0 ]-------�:01001101 01101001 01101011:�---+
|    ________                       ____ _____________ 	    |
|   /  _____/_____    _____   ____ |    |   \______   \     |
|  /   \  ___\__  \  /     \_/ __ \|    |   /|     ___/     |
|  \    \_\  \/ __ \|  Y Y  \  ___/|    |  / |    |         |
|   \______  (____  /__|_|  /\___  >______/  |____|         |
|          \/     \/      \/     \/                         |
+------------------------------------------ by .:Mik:. -----+



� WHAT IS THIS?
---------------
GameUP is a new utility for Nintendo DS that conclude the trilogy of the Up-Series homebrews 
(toghether with OsUp and SkinUP). This new program allows you to take your homebrew game 
archive ever up to date, giving the possibility to download all the best not-commercial games from 
the Nintendo DS' amateur scene.



� HOW TO USE?
-------------
Copy the patched GameUP.nds file (if your card doesn't support the autopatching) on your microSD
and run it.

For a detailed and simple guide, please take a look to the FAQ section on http://gameup.supercard.fr.



� CHANGELOG & HISTORY:
----------------------

+ v3.0 - 17/07/2009

	- Improved download function (now more stable and smoother): 
			* added possibility to abort download (pressing SELECT) avoiding microSD' corruption
			* added automatic request to retry download if something goes wrong

	- Added possibility to abort even preview's download displaying only a part of them (press 
	  SELECT for each preview's download you want to abort)

	- Decrease pad and touchscreen sensibility
	
	- More user-friendly rate displaying function (small mushrooms instead of the numeric indicator)




+ v2.0 - 17/06/2009

	- New more clear font

	- At the fist startup, GameUP will create a folder (in the root) that will be used to manage
	  all the files Gameup needs (no more bmp and txt files spread into the card)

	- Fixed a bug in listing game (repetition of some elements when print out a small list
	  after a bigger one)

	- New uploaded games are marked even on the DS through a small green mushroom next to their
	  name into the list so you can see immediatelly what's new in the game's archive.




+ v1.0 - 11/05/2009

	- First release



� THANKS TO:
------------
- supercard_sensei (from Supercard team)
- Aurelio
- Evrain
- All beta-testers, especially to Gamer4Life, Luca.Fraga and Rakztor.




      ��--[ Copyright � Michele Toriello (aka .:Mik:.) ]------------------------------------��
      |											     |
      |     The author garanted the free distribution and usage of this software at the	     |
      |   condition that there is an explicit reference to his name and to the official      |
      |   website of the project (http://gameup.supercard.fr).	                             |
      |                                                                                      |
      |     THIS SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      |
      |   IMPLIED.									     |
      |											     |
      ��--------------------------------------------------------------------------[Enjoy!]--��