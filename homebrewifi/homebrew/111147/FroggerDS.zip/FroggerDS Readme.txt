######################################
##      KDD's Frogger DS v.1.0      ##
######################################

This Game is a clone of the arcade-game "Frogger"

Changelog:
v.1.0
- Game complete!
v.0.1
- first release

Credits:
Game, Textures by King Dodongo
Music by Hasbro, "Frogger2"

Links:
http://gbatemp.net/t277177-frogger-ds
www.filetrip.net
www.Triforceseekers.de
www.youtube.com/user/KingDodongoTS
--------------------------------------
